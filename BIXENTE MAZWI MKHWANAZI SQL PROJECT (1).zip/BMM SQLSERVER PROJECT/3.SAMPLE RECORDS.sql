/*=================================================================
FileName: Insert_sample_data.sql
Programmer Name: Bixente Mazwi Mkhwanazi
Description: This file inserts sample data into the tables created for database Tygervally Pet Shelter. 
=================================================================*/

USE TygervallyPetShelter
GO

INSERT INTO AnimalCategory(categoryName)
VALUES ('Mammals'),
                ( 'Insects'),
				('Reptiles'),
				( 'Birds'),
				( 'Fish')		
GO

INSERT INTO FoodAllocation(manufacturerID, foodTypeID, categoryID, amount, measurement)
VALUES (1, 1, 1, 5.5, 'kg'),
                (1, 1, 2, 3.0, 'kg'),
				(2, 2, 2, 10,'kg'),
				(3, 3, 1, 4.5, 'kg'),
				(1, 2, 3, 6.5, 'kg' ),
				(3, 3, 3, 5, 'kg'),
				(4, 3,1, 5, 'kg')
GO

INSERT INTO FoodType(typeName, expiryDate)
VALUES ( 'Fruit and vegatables', '2024-05-01'),
				( 'Protein', '2024-06-15'),
				( 'Fat', '2024-07-28'),
				( 'Starchy Food', '2024-11-24')
GO

INSERT INTO Manufacturer(companyName, contactNumber,emailAddress)
VALUES ( 'Rescue Ranch', '0714918566', 'resrch@gmail.com'),
                ( 'Fur-ever friends', '0752825162', 'furefd@gmail.com'),
				( 'Home for hounds', '0736285273', 'hforh@gmail.com'),
				( 'Stray to Stay', '0826152721', 'sfors@gmail.com'),
				( 'Pawsitive Haven', '0841678916', 'pawsithav@gmail.com')
GO

INSERT INTO PetType(typeName,categoryID, stockLevel)
VALUES ( 'Cats', 1, 10),
                ( 'Dogs', 1, 20),
				( 'Birds', 2, 40),
				( 'Parrot', 3, 50),
				( 'Turtle', 4, 60),
				('Amphibians', 5, 70),
				('Fish', 6, 80)
GO

--Data has been inserted

PRINT 'Data is inserted successfully'
GO