/*=================================================================
FileName: Create_Triggers.sql
Programmer Name:Bixente Mazwi Mkhwanazi
Description: This file creates a trigger for the Tygervally Pet Shelter
=================================================================*/
USE TygervallyPetShelter
GO
CREATE TRIGGER tr_UpdateStockAfterInsert
ON PetType
AFTER INSERT
AS
BEGIN
    DECLARE @CategoryID INT;
    DECLARE @StockLevel INT;

    SELECT @CategoryID = CategoryID, @StockLevel = StockLevel FROM inserted;

    UPDATE AnimalCategory
    SET stockLevel = stockLevel + @StockLevel
    WHERE CategoryID = @CategoryID;
END;
GO

CREATE TRIGGER tr_UpdateStockAfterDelete
ON FoodAllocation
AFTER DELETE
AS
BEGIN
    DECLARE @CategoryID INT;
    DECLARE @Amount NUMERIC(10,2);

    SELECT @CategoryID = CategoryID, @Amount = Amount FROM deleted;

    UPDATE PetType
    SET StockLevel = StockLevel + @Amount
    WHERE CategoryID = @CategoryID;
END;
GO