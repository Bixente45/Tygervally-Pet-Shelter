 /*=============================================================
FileName: Create_Database_And_Tables.sql
Programmer: Bixente Mazwi Mkhwanazi
Description: This file will create the database and tables with the necessary constraints.
=============================================================*/

Use Master
GO

--If this database exist, we will delete it first
IF EXISTS(SELECT name FROM master.dbo.sysdatabases
	       WHERE name = 'TygervallyPetShelter')
BEGIN
	DROP DATABASE TygervalleyPetShelter 
	PRINT 'The database has been deleted'
END

--Creating the database
CREATE DATABASE TygervallyPetShelter
ON Primary
	(
	NAME = 'TygervallyPetShelter_Data',
	 FILENAME = 'c:\sqlProject\TygervallyPetShelter_data.mdf',
	 SIZE = 5MB,
	 FILEGROWTH = 10%
	 )


LOG ON
	(
	NAME = 'TygervallyPetShelter_Log',
	 FILENAME = 'c:\sqlProject\JacksMotorRepairs_Log.ldf',
	 SIZE = 5MB,
	 FILEGROWTH = 10%
	 )
GO

--Next we will create the tables. 

USE TygervallyPetShelter
GO

CREATE TABLE Manufacturer
(
manufacturerID INT NOT NULL,
companyName VARCHAR(30) NOT NULL,
contactNumber NVARCHAR(15) NOT NULL,
emailAddress VARCHAR(30) NOT NULL, 
CONSTRAINT manufacturerID_PK PRIMARY KEY (manufacturerID)
)
GO

PRINT 'The table Manufacturer has been created'
GO

CREATE TABLE FoodType
(
foodTypeID INT NOT NULL,
typeName VARCHAR(30) NOT NULL,
expiryDate DATE NOT NULL,
CONSTRAINT foodTypeID_PK PRIMARY KEY (foodTypeID)
)
GO

PRINT 'The table Food Type has been created'
GO

CREATE TABLE AnimalCategory
(
categoryID INT NOT NULL,
categoryName NVARCHAR(30) NOT NULL,
CONSTRAINT categoryID_PK PRIMARY KEY (categoryID)
)
GO

PRINT 'The table animal category has been created'
GO

CREATE TABLE PetType
(
petTypeID INT NOT NULL,
typeName NVARCHAR(30) NOT NULL,
categoryID INT FOREIGN KEY REFERENCES animalCategory(categoryID) NOT NULL,
stockLevel INT NOT NULL,
CONSTRAINT petTypeID_PK PRIMARY KEY (petTypeID)
)
GO

PRINT 'The table Pet Type has been created'
GO



CREATE TABLE FoodAllocation
(
allocationID INT NOT NULL,
manufacturerID INT FOREIGN KEY REFERENCES manufacturer(manufacturerID),
foodTypeID INT FOREIGN KEY REFERENCES foodType(foodTypeID),
categoryID INT FOREIGN KEY REFERENCES animalCategory(categoryID),
amount NUMERIC(10,2),
measurement NVARCHAR(10),
CONSTRAINT allocationID_PK PRIMARY KEY (allocationID)
)
GO

PRINT 'The table Food Allocation has been created'
GO



