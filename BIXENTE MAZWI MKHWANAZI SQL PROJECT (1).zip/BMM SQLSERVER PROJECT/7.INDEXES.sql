/*=================================================================
FileName: Create_Indexes.sql
Programmer Name:Bixente Mazwi Mkhwanazi
Description: This file creates indexes for Tygervally Pet Shelter
=================================================================*/

USE TygervallyPetShelter
GO

-- Index for Manufacturers table
CREATE INDEX idx_ManufacturerID ON Manufacturer(ManufacturerID);

-- Index for FoodTypes table
CREATE INDEX idx_FoodTypeID ON FoodType(FoodTypeID);

-- Index for AnimalCategories table
CREATE INDEX idx_CategoryID ON AnimalCategorY(CategoryID);

-- Index for PetTypes table
CREATE INDEX idx_PetTypeID ON PetType(PetTypeID);
CREATE INDEX idx_CategoryID_StockLevel ON PetType(CategoryID, StockLevel);

-- Index for FoodAllocation table
CREATE INDEX idx_ManufacturerID ON FoodAllocation(ManufacturerID);
CREATE INDEX idx_FoodTypeID ON FoodAllocation(FoodTypeID);
CREATE INDEX idx_CategoryID ON FoodAllocation(CategoryID);