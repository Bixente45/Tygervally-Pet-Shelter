/*====================================================
FileName: Create_View.sql
Programmer Name: Bixente Mazwi Mkhwanazi
Description: This file will be used to create a view for Jack Motor Repairs
=====================================================*/


USE TygervallyPetShelter
GO

--First check if the view exists, if it does, we drop it
IF EXISTS (SELECT Table_Name FROM Information_Schema.Views
	       WHERE Table_Name = 'VW_ManufacturerDetails')
BEGIN
	DROP VIEW VW_ManufacturerDetails
	PRINT 'VW_ManufacturerDetails have been deleted'
END
GO

USE TygervallyPetShelter
GO

	CREATE VIEW VW_ManufacturerDetails
	AS

SELECT manufacturer.companyName, manufacturer.contactNumber, foodType.typeName, foodType.foodTypeID, foodAllocation.amount, foodallocation.measurement, animalCategory.categoryName
FROM manufacturer
JOIN foodAllocation
ON manufacturer.manufacturerID = foodallocation.manufacturerID
JOIN foodType
ON foodAllocation.foodTypeID = foodType.foodTypeID
JOIN animalCategory
ON foodAllocation.categoryID = animalCategory.categoryID
GO

USE TygervallyPetShelter
GO
 
SELECT * FROM VW_ManufacturerDetails
GO


USE TygervallyPetShelter
GO


--First check if the view exists, if it does, we drop it
IF EXISTS (SELECT Table_Name FROM Information_Schema.Views
	       WHERE Table_Name = 'VW_PetsPerType')
BEGIN
	DROP VIEW VW_PetsPerType
	PRINT 'VW_PetsPerType have been deleted'
END
GO

 USE TygervallyPetShelter
 GO 

CREATE VIEW PetsPerType
AS

SELECT petType.typeName, petType.stockLevel, animalCategory.categoryID, animalCategory.categoryName
FROM petType
JOIN animalCategory
ON petType.categoryID = animalCategory.categoryID
GO

USE TygervallyPetShelter
GO
 
SELECT * FROM PetsPerType
GO

USE TygervallyPetShelter
GO

--First check if the view exists, if it does, we drop it
IF EXISTS (SELECT Table_Name FROM Information_Schema.Views
	       WHERE Table_Name = 'VW_ExpiredFoodDetails')
BEGIN
	DROP VIEW VW_ExpiredFoodDetails
	PRINT 'VW_ExpiredFoodDetails have been deleted'
END
GO

USE TygervallyPetShelter
GO

CREATE VIEW ExpiredFoodDetails
AS

SELECT manufacturer.companyName, manufacturer.contactNumber, foodType.foodTypeID, foodType.typeName,foodType.expiryDate, foodAllocation.amount, foodAllocation.measurement, animalCategory.categoryName
FROM manufacturer
JOIN foodAllocation
ON manufacturer.manufacturerID = foodAllocation.manufacturerID
JOIN foodType
ON foodAllocation.foodTypeID = foodType.foodTypeID
JOIN animalCategory
ON foodAllocation.categoryID = animalCategory.categoryID
WHERE foodType.expiryDate < GETDATE()
GO

USE TygervallyPetShelter
GO
 
SELECT * FROM ExpiredFoodDetails
GO


USE TygervallyPetShelter
GO


--First check if the view exists, if it does, we drop it
IF EXISTS (SELECT Table_Name FROM Information_Schema.Views
	       WHERE Table_Name = 'VW_LowestFoods')
BEGIN
	DROP VIEW VW_LowestFoods
	PRINT 'VW_LowestFoods have been deleted'
END
GO


USE TygervallyPetShelter
GO

CREATE VIEW LowestFoods 
AS

SELECT TOP 3 animalCategory.categoryName AS categoryName,  SUM(petType.stockLevel) AS TotalAnimals
FROM PetType
JOIN animalCategory 
ON petType.categoryID = animalCategory.categoryID
GROUP BY animalCategory.categoryName
ORDER BY TotalAnimals

USE TygervallyPetShelter
GO
 
SELECT * FROM LowestFoods
GO
