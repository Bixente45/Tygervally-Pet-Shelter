/*=================================================================
FileName: Create_Insert_Procedure.sql
Programmer Name: Bixente Mazwi Mkhwanazi
Description: This file creates an insert procedure that allows us to add more spares to our records.
=================================================================*/


USE TygervallyPetShelter
GO
-- Stored procedure to insert a new pet type record
CREATE PROCEDURE sp_NewPetType
    @PetTypeName NVARCHAR(100),
    @CategoryID INT,
    @StockLevel INT
AS
BEGIN
    IF EXISTS (SELECT 1 FROM AnimalCategory WHERE CategoryID = @CategoryID)
    BEGIN
        INSERT INTO PetType (typeName, CategoryID, StockLevel) VALUES (@PetTypeName, @CategoryID, @StockLevel);
        PRINT 'New pet type inserted successfully.';
    END
    ELSE
    BEGIN
        PRINT 'Error: Invalid CategoryID. Please provide an existing CategoryID.';
    END
END;

GO
-- Stored procedure to update an existing pet type record
CREATE PROCEDURE sp_UpdateStock
    @PetTypeID INT,
    @Amount INT,
    @Addition BIT
AS
BEGIN
    IF @Addition = 1
    BEGIN
        UPDATE PetType SET StockLevel = StockLevel + @Amount WHERE PetTypeID = @PetTypeID;
    END
    ELSE IF @Addition = 0
    BEGIN
        UPDATE PetType SET StockLevel = StockLevel - @Amount WHERE PetTypeID = @PetTypeID;
    END
    ELSE
    BEGIN
        PRINT 'Error: Invalid value for the Addition parameter. Use 1 for addition and 0 for subtraction.';
    END
END;


GO
-- Stored procedure to delete a specified food type and all dependent/child records if it is contained in the v_ExpiredFoodDetails view
CREATE PROCEDURE sp_DeleteFoodType
    @FoodTypeID INT
AS
BEGIN
    IF EXISTS (SELECT 1 FROM vw_ExpiredFoodDetails WHERE FoodTypeID = @FoodTypeID)
    BEGIN
        DELETE FROM FoodAllocation WHERE FoodTypeID = @FoodTypeID;
        DELETE FROM FoodType WHERE FoodTypeID = @FoodTypeID;
        PRINT 'Food type and dependent records deleted successfully.';
    END
    ELSE
    BEGIN
        PRINT 'Error: The specified food type does not exist or is not expired.';
    END
END;
GO

-- Stored procedure to generate a report for a specified manufacturing company's details and all its expired products in use
CREATE PROCEDURE sp_Report
    @ManufacturerID INT
AS
BEGIN
    DECLARE @CompanyName NVARCHAR(100)
    DECLARE @ContactNumber NVARCHAR(20)
    DECLARE @Email NVARCHAR(100)

    -- Get company details
    SELECT @CompanyName = CompanyName, @ContactNumber = ContactNumber, @Email = Email
    FROM Manufacturer
    WHERE ManufacturerID = @ManufacturerID;

    IF @@ROWCOUNT > 0
    BEGIN
        -- Print header
        PRINT '----------------------------------------'
        PRINT 'Report for ' + @CompanyName
        PRINT 'Contact Number: ' + @ContactNumber
        PRINT 'Email: ' + @Email
        PRINT 'Date: ' + CONVERT(NVARCHAR(30), GETDATE(), 120)
        PRINT '----------------------------------------'

        -- Print expired products in use
        SELECT CompanyName, ContactNumber, foodType.FoodTypeID, foodType.typeName, FoodType.ExpiryDate, foodAllocation.Amount, foodAllocation.Measurement, animalCategory.categoryName 
		FROM manufacturer
        JOIN FoodAllocation 
		ON manufacturer.manufacturerID = foodAllocation.manufacturerID
        JOIN FoodType  
		ON foodAllocation.foodTypeID = foodType.FoodTypeID
        JOIN animalCategory 
		ON foodAllocation.CategoryID = animalCategory.CategoryID
        WHERE foodType.ExpiryDate < GETDATE() AND manufacturer.manufacturerID = @ManufacturerID;
    END
    ELSE
    BEGIN
        PRINT 'Error: Manufacturer not found.';
    END
END;
